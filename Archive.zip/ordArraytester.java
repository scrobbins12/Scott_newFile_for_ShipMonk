public class ordArraytester {
public static void main (String [] args){
    ordArray b= new ordArray(10);
        b.insert(4);
        b.insert(2);
        b.insert(3);
        b.insert(100);
        b.insert(48);
        //b.find(2);
        b.display();
        b.remove(7);
        b.display();
    }
}