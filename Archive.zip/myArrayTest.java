public class myArrayTest {
    public static void main (String [] args){
        MyArray a= new MyArray(5);
        ordArray b= new ordArray(10);
        a.insert(5);
        a.insert(2);
        a.insert(3);
        a.insert(4);
        a.insert(5);
        //a.findMax();
        //a.findMin();
        //a.find(4);
        //a.find(7);
        //a.total();
        //a.average();
        //a.remove(3);
        //a.remove(1);
        //a.removeMax();
        //a.removeMin();
        //a.remove(2;
        //)
        //a.remove(9);
        //a.removeMax();
        //a.removeMin();
        //a.reverseArray();
        //a.allDistinct();
        //a.average();
        //a.display();
        b.insert(4);
        b.insert(3);
        b.insert(10);
        b.display();
    }
}