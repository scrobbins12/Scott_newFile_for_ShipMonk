public class MyArray{
    public int[] array;
    private int n;
    public MyArray(int size){
        array=new int [size];
        n=0;
    }
        public void insert(int value){
            array[n]=value;
            n++;
        }
        public int findMax(){
            if (array.length==0){
                return -1;}
            int max=array[0];
            for (int i=0; i<array.length;i++){
                if (array[i]>max){
                    max=array[i];
                }
            }
            System.out.println(max);
            return max;
        }
        public int findMin(){
            if (n==0){
                return -1;
            }
            int min=array[0];
            for (int i=0; i<n;i++){
                if (array[i]<min){
                    min=array[i];
                 }
            }
            System.out.println(min);
            return min;
        }
        public boolean find(int num){
            for (int i=0;i<n;i++){
                if (array[i]==num){
                    System.out.println("true");
                    return true;}
            }
            System.out.println("false");
            return false;
        }
        public int total(){
            int total=0;
            for (int i=0; i<n; i++){
                total=array[i]+total;
            }
            System.out.println(total);
            return total;
        }
        public int average(){
            int avg=total()/n;
            System.out.println(avg);
            return avg;
        }
        public void reverseArray(){
            int orgnum;
            int len=array.length;
            for (int i=0; i<(len/2); i++){
                orgnum=array[i];
                array[i]=array[len-i-1];
                array[len-i-1]=orgnum;
            }
        }
        public boolean remove(int value){
            int orgnum;
            if (find(value)==true) {
                for (int i=0; i<array.length;i++){
                    if (array[i]==value){
                        orgnum=array[i];
                        array[i]=array[n-1];
                        array[n-1]=-1;
                        n--;
                        return true;
                    }
                }
            }
            System.out.println("Error: the number is not in the array");
            return false;
        }
        public void removeMax(){
            int max=findMax();
            remove(max);
        }
        public void removeMin(){
            int min=findMin();
            remove(min);}
        public boolean allDistinct(){
            for (int i=0; i<n;i++){
                for (int j=0; j<n; j++){
                    if (array[i]==array[j] && i != j){
                        System.out.println("false");
                         return false;
                    }
                }
            }
            System.out.println("true");
            return true;
        }
        public void display(){
            if (n<1){
                System.out.println("empty");
            }
            for (int i=0; i<n; i++){
                System.out.println(array[i]);
            }
        }
    }