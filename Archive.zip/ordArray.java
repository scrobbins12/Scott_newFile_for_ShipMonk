public class ordArray {
    private int [] array;
    private int n;
    public ordArray(int maxsize){
        array=new int[maxsize];
        n=0;
    }
    public void sort(){
        int orgnum;
        for (int i=0; i<n-1;i++){
            if (array[i]>array[i+1]){
                orgnum=array[i];
                array[i]=array[i+1];
                array[i+1]=orgnum;
            }
        }
    } 
    public boolean remove(int value){
        for (int i=0; i<n; i++){
            if (array[i]==value){
                for (int j=i; j<n-1; j++){
                    array[j]=array[j+1];
                }
                n--;
                return true;
            }
        }
        return false;
    }
        // int insertPos;
        // int key;
        // if (find(value)==true){
        //     for (int i=0; i<array.length;i++){
        //         key=array[i];
        //         insertPos=i;
        //         while (insertPos>0 && array[insertPos-1]>key) {
        //             array[insertPos]=array[insertPos-1];
        //             insertPos--;
        //         }
        //     }
        //     insertPos;
        //     int orgnum;
        //     for (int j=insertPos;j<n;j++){
        //         array[j-1]=array[j];
        //         //do I need to decrement size?
        //     }
        // return true;
        // }
        // return false;
    public boolean find(int value){
        int start=0;
        int end=n-1;
        int mid;
        while (start<=end){//as long as array is not empty
            mid=(start+end)/2;
            if (array[mid]<value){
                start=mid+1;
            }
            else if (array[mid]>value){
                end=mid-1;
            }
            else if (array[mid]==value){
                return true;
            }
        }
        return false;
    }
    public void insert(int value){//value is just value that we want to insert
        int i=0;
        if (n!=0){
            if (value>array[n-1]){
                array[n]=value;
                n++;
                return;
            }
            else{
                while (array[i]<value){
                    i++;
                }
                for (int j=n; j>i; j--){
                    array[j]=array[j-1];
                }
            }
        }
        array[i]=value;
        n++;
    }
    public void display(){
        if (n<1){
            System.out.println("Empty");
        }
        else{
            for (int i=0; i<n;i++){
                System.out.println(array[i]);
            }
        }
    }
}